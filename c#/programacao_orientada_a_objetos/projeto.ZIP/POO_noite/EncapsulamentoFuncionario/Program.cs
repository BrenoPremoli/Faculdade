﻿// função Main() implícita

using EncapsulamentoFuncionario;

Funcionario f1 = new Funcionario();
f1.Codigo = 12;//set esta sendo executado
Console.WriteLine("Código do funcionário: " + f1.Codigo);//get

