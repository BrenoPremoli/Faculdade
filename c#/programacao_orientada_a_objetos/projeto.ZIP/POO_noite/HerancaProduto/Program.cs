﻿// função Main()

using HerancaProduto;

Produto p = new Produto(1,"mouse",100);
p.Mostrar();

Perecivel pe = new Perecivel(2, "arroz", 20, "04/05/2023", "06/05/2023",22);
pe.Mostrar();