using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConstrutorConta
{
    public static class ClasseEstat
    {
        public static void MostrarFrase()
        {
            Console.WriteLine("Hello world!!!!!!!");
        }
    }
}